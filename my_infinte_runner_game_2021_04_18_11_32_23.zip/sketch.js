var ghost,ghostani,door,doorimg,tower,towerimg;
var gamestate = "play";


function preload(){
  ghostani=loadImage("ghost-standing.png","ghost-standing.png");
  towerimg=loadImage("tower.png");
  doorimg=loadImage("door.png");
  climberimg=loadImage("climber.png");
  
}

function setup(){
  createCanvas(400,400);
  tower=createSprite(200,200);
  tower.addImage(towerimg);
  tower.scale=0.7
  
  ghost=createSprite(200,200);
  ghost.addImage(ghostani);
  ghost.scale=0.3
  
  doorsGroup=new Group();
  climbersGroup=new Group();
  
  ivGroup=new Group();
  
}

function draw(){
  if(gamestate==="play"){
    
  tower.velocityY=2
  if(tower.y>400){
    tower.y=200;
  }
  if(keyDown("space")){
    ghost.velocityY=-3;
    
  }
  ghost.velocityY=ghost.velocityY+0.5
  if(keyDown(LEFT_ARROW)){
    ghost.x=ghost.x-3;
  }
  if(keyDown(RIGHT_ARROW)){
    ghost.x=ghost.x+3;
  }
  if(climbersGroup.isTouching(ghost)){
    ghost.velocityY=0;
  }
    if(ivGroup.isTouching(ghost)||ghost.y>400){
      ghost.destroy();
      gamestate="end";
    }
  doors();
  }
  drawSprites(); 
  if(gamestate==="end"){
    background("black");
    textSize(30);
    text("GAMEOVER",130,200);
  }
}

function doors(){
  if(frameCount%200===0){
    door=createSprite(200,-50)
    door.addImage(doorimg);
    
    climber=createSprite(200,10);
    climber.addImage(climberimg);
    
    invisibleblock=createSprite(200,15);
    invisibleblock.width=climber.width;
    invisibleblock.height=2;
    
    door.x=Math.round(random(80,330))
    door.velocityY=1;
    door.depth=ghost.depth;
    ghost.depth=ghost.depth+1
    
    climber.x=door.x;
    climber.velocityY=1;
    
    invisibleblock.x=door.x;
    invisibleblock.velocityY=1;
    climber.lifetime=400;
    climbersGroup.add(climber); 
    
    invisibleblock.lifetime=400;
    ivGroup.add(invisibleblock);
    
    door.lifetime=400;
    doorsGroup.add(door);
  }
}